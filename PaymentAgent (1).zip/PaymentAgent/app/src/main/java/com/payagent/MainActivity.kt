package com.payagent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Context.startAgent() { ContextCompat.startForegroundService(this, Intent(this, AgentService::class.java)) }
private fun hms(t: Long) = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(t))
private fun statusColor(s: String) = when (s) {
    "CONFIRMED", "SYSTEM_ON" -> Color(0xFF12A05F); "REJECTED", "SYSTEM_OFF" -> Color(0xFFE0483A)
    "WAITING" -> Color(0xFFE09A12); "EXCEPTION" -> Color(0xFF8E4FB5); else -> Color(0xFF7A8A82)
}

// ---------- Theme ----------
private val LightScheme = lightColorScheme(
    primary = Color(0xFF0A7D4F), onPrimary = Color.White, primaryContainer = Color(0xFFD7F3E5), onPrimaryContainer = Color(0xFF05361F),
    background = Color(0xFFF3F6F4), surface = Color(0xFFF3F6F4), onBackground = Color(0xFF14201A), onSurface = Color(0xFF14201A),
    surfaceVariant = Color(0xFFE3EAE6), onSurfaceVariant = Color(0xFF5A6B62), outline = Color(0xFFD3DDD8), error = Color(0xFFC0392B))
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF3DD68C), onPrimary = Color(0xFF00391F), primaryContainer = Color(0xFF0B3D29), onPrimaryContainer = Color(0xFFBDF2D6),
    background = Color(0xFF0E1511), surface = Color(0xFF0E1511), onBackground = Color(0xFFE6F0EA), onSurface = Color(0xFFE6F0EA),
    surfaceVariant = Color(0xFF1B2620), onSurfaceVariant = Color(0xFF9DB0A6), outline = Color(0xFF2B3A32), error = Color(0xFFFF6B5B))

@Composable private fun muted() = MaterialTheme.colorScheme.onSurfaceVariant
@Composable private fun cardBg() = if (isSystemInDarkTheme()) Color(0xFF16201B) else Color.White

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, highlight: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val m = modifier.fillMaxWidth()
    val border = BorderStroke(if (highlight) 2.dp else 1.dp, if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
    val colors = CardDefaults.cardColors(containerColor = cardBg())
    val shape = RoundedCornerShape(20.dp)
    if (onClick != null) Card(onClick = onClick, modifier = m, shape = shape, colors = colors, border = border) { Column(Modifier.padding(16.dp)) { content() } }
    else Card(modifier = m, shape = shape, colors = colors, border = border) { Column(Modifier.padding(16.dp)) { content() } }
}

@Composable
fun Chip(s: String) {
    val c = statusColor(s)
    Surface(shape = RoundedCornerShape(50), color = c.copy(alpha = 0.15f)) {
        Text(s.replace('_', ' '), color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
    }
}

@Composable fun Section(t: String) { Text(t.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = muted(), letterSpacing = 1.sp, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)) }
@Composable fun Empty(t: String) { Text(t, color = muted(), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp)) }

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        enableEdgeToEdge()
        val perms = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}.launch(perms.toTypedArray())
        if (Store.loggedIn()) startAgent()
        setContent { AppRoot() }
    }
}

class TabDef(val label: String, val icon: ImageVector)

@Composable
fun AppRoot() {
    val v = Ui.v.intValue
    val logged = remember(v) { Store.loggedIn() }
    var tab by remember { mutableIntStateOf(0) }
    val exN = remember(v) { Db.counts()["EXCEPTION"] ?: 0 }
    LaunchedEffect(Unit) { while (true) { delay(5000); if (Store.token != null && !Store.loggedIn()) Session.logout("Session expired") } }
    val tabs = listOf(TabDef("Home", Icons.Filled.Home), TabDef("Payments", Icons.Filled.Menu), TabDef("Verify", Icons.Filled.Search),
        TabDef("Alerts", Icons.Filled.Warning), TabDef("History", Icons.Filled.DateRange), TabDef("Settings", Icons.Filled.Settings))
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (!logged) Login() else Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = {
                NavigationBar(containerColor = cardBg()) {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = {
                                if (t.label == "Alerts" && exN > 0) BadgedBox(badge = { Badge { Text(exN.toString()) } }) { Icon(t.icon, t.label) }
                                else Icon(t.icon, t.label)
                            },
                            label = { Text(t.label, fontSize = 10.sp, maxLines = 1) })
                    }
                }
            }) { p ->
                Column(Modifier.padding(p).padding(horizontal = 16.dp, vertical = 8.dp).verticalScroll(rememberScrollState())) {
                    when (tab) { 0 -> Home(v); 1 -> Payments(v); 2 -> Verify(v); 3 -> Exceptions(v); 4 -> History(v); else -> Settings(v) }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
fun Header(title: String, v: Int) {
    val on = remember(v) { Store.automationOn }
    val srv = remember(v) { Store.serverEnabled }
    val label = when { !on -> "AUTOMATION OFF"; !srv -> "PAUSED BY MANAGEMENT"; else -> "AUTOMATION ON" }
    val col = when { !on -> statusColor("REJECTED"); !srv -> statusColor("WAITING"); else -> MaterialTheme.colorScheme.primary }
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(if (Store.demo) "Demo mode" else Store.baseUrl.removePrefix("https://"), fontSize = 12.sp, color = muted())
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = col, letterSpacing = 0.5.sp)
            Switch(checked = on, onCheckedChange = { Control.set(it) })
        }
    }
}

@Composable
fun Login() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(Store.baseUrl) }
    var u by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A7D4F), Color(0xFF053D27)))).systemBarsPadding().padding(24.dp)) {
        Column(Modifier.align(Alignment.Center).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Text("💸", fontSize = 34.sp) }
            Spacer(Modifier.height(14.dp))
            Text("Payment Automation", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Sign in with your management account", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            AppCard {
                OutlinedTextField(url, { url = it }, label = { Text("Management system URL") }, singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(u, { u = it }, label = { Text("Username") }, singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(pw, { pw = it }, label = { Text("Password") }, singleLine = true, shape = RoundedCornerShape(14.dp),
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
                Spacer(Modifier.height(14.dp))
                Button(enabled = !busy && u.isNotEmpty() && pw.isNotEmpty(), shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp), onClick = {
                        busy = true; err = null
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { runCatching { Store.baseUrl = url; Api.login(u, pw) } }
                            busy = false
                            r.onSuccess { pw = ""; ctx.startAgent(); Ui.bump() }
                                .onFailure { err = if (it is Api.Unauthorized) "Invalid credentials" else "Login failed: ${it.message}" }
                        }
                    }) { Text(if (busy) "Signing in…" else "Sign in", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            }
            TextButton(onClick = { Demo.start(); ctx.startAgent(); Ui.bump() }) { Text("Try demo mode (no server)", color = Color.White) }
        }
    }
}

@Composable
fun Stat(m: Modifier, label: String, n: Int, c: Color) {
    AppCard(m.padding(3.dp)) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(c))
        Spacer(Modifier.height(6.dp))
        Text(n.toString(), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 12.sp, color = muted())
    }
}

@Composable
fun TxCard(t: Tx, extra: @Composable ColumnScope.() -> Unit = {}) {
    AppCard(Modifier.padding(vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(Fmt.money(t.cents, t.currency), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Chip(t.status)
        }
        Text(t.txnId ?: "(no ID)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text("${t.wallet ?: "?"} · ${hms(t.ts)}", fontSize = 12.sp, color = muted())
        t.reason?.let { Text(it, fontSize = 12.sp, color = muted(), modifier = Modifier.padding(top = 4.dp)) }
        extra()
    }
}

@Composable
fun Home(v: Int) {
    val c = remember(v) { Db.counts() }
    val pending = remember(v) { Db.requests("PENDING") }
    val recent = remember(v) { Db.txs().take(5) }
    val on = Store.automationOn; val srv = Store.serverEnabled
    Header("Dashboard", v)
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
        .background(Brush.linearGradient(if (on && srv) listOf(Color(0xFF0A7D4F), Color(0xFF16B573)) else listOf(Color(0xFF55615B), Color(0xFF7A8A82)))).padding(20.dp)) {
        Column {
            Text("System status", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Text(if (!on) "Switched off" else if (!srv) "Paused by management" else "Running", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(if (!on) "No automatic decisions. Payments wait until you switch on." else if (!srv) "The management system has paused automation." else "Payments are confirmed or rejected automatically.",
                color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Row {
                Column(Modifier.weight(1f)) { Text((c["CONFIRMED"] ?: 0).toString(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Confirmed", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp) }
                Column(Modifier.weight(1f)) { Text(pending.size.toString(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Pending", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp) }
                Column(Modifier.weight(1f)) { Text((c["EXCEPTION"] ?: 0).toString(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Need you", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp) }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Row { Stat(Modifier.weight(1f), "Rejected", c["REJECTED"] ?: 0, statusColor("REJECTED")); Stat(Modifier.weight(1f), "Waiting", c["WAITING"] ?: 0, statusColor("WAITING")); Stat(Modifier.weight(1f), "Exceptions", c["EXCEPTION"] ?: 0, statusColor("EXCEPTION")) }
    Section("Pending requests")
    pending.forEach { r ->
        AppCard(Modifier.padding(vertical = 4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(r.id, fontWeight = FontWeight.Bold); Text(Fmt.money(r.cents, r.currency), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Text("${r.name} · ${r.wallet} · ${r.provider}", fontSize = 12.sp, color = muted())
            if (r.screenshotUrl != null || r.reference != null) Text("Proof attached", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
    if (pending.isEmpty()) Empty("No pending requests")
    Section("Recent activity")
    recent.forEach { TxCard(it) }
    if (recent.isEmpty()) Empty("No transactions yet")
}

@Composable
fun Payments(v: Int) {
    Header("Payments", v)
    val l = remember(v) { Db.txs() }
    l.forEach { TxCard(it) }
    if (l.isEmpty()) Empty("No payments yet")
}

@Composable
fun Exceptions(v: Int) {
    val scope = rememberCoroutineScope()
    val list = remember(v) { Db.txs("EXCEPTION") }
    Header("Needs attention", v)
    if (list.isEmpty()) Empty("All clear. The engine is handling everything.")
    list.forEach { t ->
        TxCard(t) {
            Text("Raw: ${t.raw}", fontSize = 11.sp, color = muted(), maxLines = 4, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(10.dp))
            Row {
                Button(shape = RoundedCornerShape(12.dp), onClick = { scope.launch(Dispatchers.IO) { Engine.manual(t.id, "CONFIRMED") } }) { Text("Confirm") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(shape = RoundedCornerShape(12.dp), onClick = { scope.launch(Dispatchers.IO) { Engine.manual(t.id, "REJECTED") } }) { Text("Reject") }
            }
        }
    }
}

@Composable
fun History(v: Int) {
    Header("Audit log", v)
    val l = remember(v) { Db.auditList() }
    l.forEach { a ->
        AppCard(Modifier.padding(vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(a.reqId ?: "System", fontWeight = FontWeight.Bold); Chip(a.decision)
            }
            Text("Txn ${a.txnId ?: "-"} · ${hms(a.ts)} · ${a.source}", fontSize = 11.sp, color = muted())
            Text(a.detail, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
    if (l.isEmpty()) Empty("No decisions yet")
}

@Composable
fun Verify(v: Int) {
    val scope = rememberCoroutineScope()
    val pending = remember(v) { Db.requests("PENDING") }
    var provider by remember { mutableStateOf("TELEBIRR") }
    var ref by remember { mutableStateOf("") }
    var selId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var res by remember { mutableStateOf<Verifier.VResult?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    val sel = pending.firstOrNull { it.id == selId }
    Header("Verify payment", v)
    AppCard {
        Row {
            FilterChip(selected = provider == "TELEBIRR", onClick = { provider = "TELEBIRR" }, label = { Text("Telebirr") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = provider == "CBEBIRR", onClick = { provider = "CBEBIRR" }, label = { Text("CBE Birr") })
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(ref, { ref = it.trim().uppercase() }, label = { Text("Reference / receipt number") }, singleLine = true,
            shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Button(enabled = !busy && ref.length >= 6, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(50.dp), onClick = {
            busy = true; err = null; res = null
            val p = provider; val rr = ref
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { Verifier.check(p, rr) } }
                busy = false
                r.onSuccess { res = it }.onFailure { err = it.message ?: "Verification failed" }
            }
        }) { Text(if (busy) "Checking…" else "Check reference", fontWeight = FontWeight.SemiBold) }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
    }
    Section("Match against a request")
    pending.forEach { r ->
        AppCard(Modifier.padding(vertical = 4.dp), onClick = { selId = if (selId == r.id) null else r.id }, highlight = selId == r.id) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.id, fontWeight = FontWeight.Bold); Text(Fmt.money(r.cents, r.currency), fontWeight = FontWeight.Bold) }
            Text("${r.name} · ${r.wallet} · ${r.provider}", fontSize = 12.sp, color = muted())
        }
    }
    if (pending.isEmpty()) Empty("No pending requests")
    res?.let { vr ->
        Section("Verifier result")
        AppCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(Fmt.money(vr.cents, "ETB"), fontSize = 24.sp, fontWeight = FontWeight.Bold); Chip(if (vr.success) "CONFIRMED" else "REJECTED")
            }
            Text("Status: ${vr.status}", fontSize = 13.sp)
            Text("Payer: ${vr.payer ?: "?"}", fontSize = 13.sp)
            Text("Receiver: ${vr.receiver ?: "?"}", fontSize = 13.sp)
            Text("Date: ${vr.dateText ?: "?"}", fontSize = 13.sp)
            if (sel != null) {
                val e = Engine.evaluateProof(sel, vr)
                Spacer(Modifier.height(10.dp))
                Text("Engine verdict: ${e.decision} - ${e.reason}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                e.rules.forEach { Text((if (it.ok) "✓ " else "✗ ") + it.name, fontSize = 12.sp, color = if (it.ok) statusColor("CONFIRMED") else statusColor("REJECTED")) }
                Spacer(Modifier.height(12.dp))
                Row {
                    Button(shape = RoundedCornerShape(12.dp), onClick = { scope.launch(Dispatchers.IO) { Engine.manualProof(sel, vr, "CONFIRMED") }; res = null; ref = ""; selId = null }) { Text("Confirm payment") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(shape = RoundedCornerShape(12.dp), onClick = { scope.launch(Dispatchers.IO) { Engine.manualProof(sel, vr, "REJECTED") }; res = null; ref = ""; selId = null }) { Text("Reject") }
                }
            } else Text("Select a request above to confirm or reject.", fontSize = 12.sp, color = muted(), modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun Settings(v: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var retry by remember { mutableStateOf(Store.retrySec.toString()) }
    var max by remember { mutableStateOf(Store.maxAttempts.toString()) }
    var senders by remember { mutableStateOf(Store.senders) }
    var vurl by remember { mutableStateOf(Store.verifierUrl) }
    var vkey by remember { mutableStateOf(Store.verifierKey) }
    var mw by remember { mutableStateOf(Store.merchantWallet) }
    var test by remember { mutableStateOf("") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    val shape = RoundedCornerShape(14.dp)
    Header("Settings", v)
    Section("Engine rules")
    AppCard {
        OutlinedTextField(retry, { retry = it; it.toIntOrNull()?.let { n -> if (n in 1..600) Store.retrySec = n } },
            label = { Text("Retry / sync interval (seconds)") }, keyboardOptions = num, singleLine = true, shape = shape, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(max, { max = it; it.toIntOrNull()?.let { n -> if (n in 1..50) Store.maxAttempts = n } },
            label = { Text("Max retries before exception") }, keyboardOptions = num, singleLine = true, shape = shape, modifier = Modifier.fillMaxWidth())
    }
    Section("SMS")
    AppCard {
        OutlinedTextField(senders, { senders = it; Store.senders = it }, label = { Text("Allowed sender IDs (comma-separated)") },
            singleLine = true, shape = shape, modifier = Modifier.fillMaxWidth())
    }
    Section("Receipt verification")
    AppCard {
        OutlinedTextField(vurl, { vurl = it; Store.verifierUrl = it }, label = { Text("Verifier API URL") }, singleLine = true, shape = shape, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(vkey, { vkey = it; Store.verifierKey = it.trim() }, label = { Text("Verifier API key") }, singleLine = true, shape = shape,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(mw, { mw = it; Store.merchantWallet = it.trim() }, label = { Text("My receiving wallet (09...)") },
            keyboardOptions = num, singleLine = true, shape = shape, modifier = Modifier.fillMaxWidth())
    }
    Section("Test a payment message")
    AppCard {
        OutlinedTextField(test, { test = it }, label = { Text("Paste payment SMS text") }, shape = shape, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(enabled = test.isNotBlank(), shape = shape, onClick = { val t = test; test = ""; scope.launch(Dispatchers.IO) { Intake.ingest(t) } }) { Text("Process message") }
    }
    Section("Account")
    OutlinedButton(shape = shape, modifier = Modifier.fillMaxWidth().height(50.dp),
        onClick = { ctx.stopService(Intent(ctx, AgentService::class.java)); Session.logout() }) { Text("Log out") }
}
