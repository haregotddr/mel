package com.payagent

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import kotlin.concurrent.thread

/** REST client for the management system. Uses the login session token for every call. */
object Api {
    class Unauthorized : Exception()

    private fun call(method: String, path: String, body: String?, token: String?, idem: String? = null): String {
        if (!Store.baseUrl.startsWith("https://")) throw Exception("HTTPS is required")
        val c = URL(Store.baseUrl + path).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 10_000; c.readTimeout = 15_000
        c.setRequestProperty("Content-Type", "application/json")
        token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        idem?.let { c.setRequestProperty("Idempotency-Key", it) }
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code == 401) throw Unauthorized()
        if (code == 409) return text // already recorded server-side (idempotent)
        if (code !in 200..299) throw Exception("HTTP $code")
        return text
    }

    fun login(user: String, pass: String) {
        val t = call("POST", "/api/auth/login", JSONObject().put("username", user).put("password", pass).toString(), null)
        val o = JSONObject(t)
        val tok = o.optString("token").ifEmpty { o.optString("access_token") }
        if (tok.isEmpty()) throw Exception("No token in response")
        Store.demo = false
        Store.token = tok
        Store.tokenExp = System.currentTimeMillis() + (if (o.has("expires_in")) o.getLong("expires_in") * 1000 else 15 * 60_000L)
    }

    private fun time(o: JSONObject, k: String, def: Long): Long = when (val v = o.opt(k)) {
        is Number -> v.toLong().let { if (it < 10_000_000_000L) it * 1000 else it }
        is String -> runCatching { Instant.parse(v).toEpochMilli() }.getOrNull() ?: v.toLongOrNull() ?: def
        else -> def
    }

    private fun first(o: JSONObject, vararg keys: String): String? =
        keys.firstNotNullOfOrNull { k -> o.optString(k, "").trim().takeIf { it.isNotEmpty() && it != "null" } }

    fun fetchPending(): List<Req> {
        val t = call("GET", "/api/payment-requests?status=PENDING", null, Store.token)
        val arr = if (t.trimStart().startsWith("[")) JSONArray(t) else JSONObject(t).optJSONArray("items") ?: JSONArray()
        val now = System.currentTimeMillis()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val cents = Norm.cents(o.opt("amount")?.toString()) ?: return@mapNotNull null
            val raw = o.optString("wallet_number")
            Req(o.getString("request_id"), o.optString("user_id"), o.optString("customer_name"), Norm.wallet(raw) ?: raw,
                cents, o.optString("currency", "ETB"), o.optString("provider", "Telebirr"),
                time(o, "created_at", now), time(o, "expiration_time", now + 30 * 60_000), "PENDING",
                first(o, "screenshot_url", "screenshot", "image_url", "proof_url"), first(o, "reference", "transaction_reference", "ref_no"))
        }
    }

    /** Tells the management system whether automation is on, and lets it switch the system off remotely. */
    fun heartbeat() {
        val body = JSONObject().put("enabled", Store.automationOn).put("active", Store.active())
            .put("at", Instant.now().toString()).toString()
        val t = call("POST", "/api/agent/status", body, Store.token)
        try {
            val o = JSONObject(t)
            if (o.has("enabled")) {
                val old = Store.serverEnabled; val now = o.getBoolean("enabled")
                Store.serverEnabled = now
                if (old != now) { Notifier.post("Automation " + (if (now) "resumed" else "paused") + " by management", ""); Ui.bump() }
            }
        } catch (_: Exception) {}
    }

    fun push(key: String, body: String) { call("POST", "/api/decisions", body, Store.token, key) }
}

object Sync {
    private var failing = false
    fun fresh() = Store.demo || System.currentTimeMillis() - Store.lastSync < 60_000

    fun once() {
        if (Store.demo) { Store.lastSync = System.currentTimeMillis(); Db.outboxClear(); return }
        try {
            Api.fetchPending().forEach(Db::insertRequestIfNew)
            try { Api.heartbeat() } catch (e: Api.Unauthorized) { throw e } catch (_: Exception) {}
            Store.lastSync = System.currentTimeMillis()
            while (true) { // report decisions; keep them queued if the server is unreachable
                val o = Db.outboxNext() ?: break
                Api.push(o.key, o.body); Db.outboxDelete(o.id)
            }
            failing = false
            Ui.bump()
        } catch (e: Api.Unauthorized) {
            Session.logout("Management session expired – please log in again")
        } catch (e: Exception) {
            if (!failing) { failing = true; Notifier.post("Connection problem", "Cannot reach the management system. No decisions are made while offline.") }
        }
    }
}

class AgentService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val n = Notifier.foreground(this)
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)
        if (job == null) job = scope.launch {
            while (isActive) {
                if (!Store.loggedIn()) {
                    if (Store.token != null) Session.logout("Session expired – please log in again")
                    stopSelf(); return@launch
                }
                try { Sync.once(); if (Sync.fresh()) Proof.runPending(); Engine.tick() } catch (_: Exception) {}
                delay(Store.retrySec * 1000L)
            }
        }
        return START_STICKY
    }
    override fun onDestroy() { scope.cancel() }
}

/** Receives incoming SMS; only allow-listed senders are read, everything else is ignored. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val sender = msgs.firstOrNull()?.originatingAddress ?: return
        if (!Store.senderAllowed(sender)) return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val p = goAsync()
        thread { try { Intake.ingest(body) } finally { p.finish() } }
    }
}

object Demo {
    fun start() {
        Store.demo = true; Store.token = "demo"; Store.tokenExp = System.currentTimeMillis() + 15 * 60_000
        val n = System.currentTimeMillis()
        listOf(Req("DEP-102938", "123456", "Abebe Kebede", "0911223344", 50000, "ETB", "Telebirr", n - 120_000, n + 1_800_000, "PENDING"),
            Req("DEP-102939", "123457", "Tigist Alemu", "0922334455", 120000, "ETB", "Telebirr", n - 120_000, n + 1_800_000, "PENDING"),
            Req("DEP-102940", "123458", "Dawit Mekonnen", "0933445566", 25050, "ETB", "Telebirr", n - 120_000, n + 1_800_000, "PENDING"))
            .forEach(Db::insertRequestIfNew)
    }
}

/** Master ON/OFF switch for the whole automation system. */
object Control {
    fun set(on: Boolean) {
        Store.automationOn = on
        Db.audit(null, null, if (on) "SYSTEM_ON" else "SYSTEM_OFF", "Automation switched " + (if (on) "ON" else "OFF") + " by agent", "AGENT_MANUAL")
        Ui.bump()
        thread {
            if (!Store.demo && Store.loggedIn()) try { Api.heartbeat() } catch (_: Exception) {}
            if (on) try { Engine.tick() } catch (_: Exception) {}
        }
    }
}
