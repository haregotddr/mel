package com.payagent

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Req(val id: String, val userId: String, val name: String, val wallet: String, val cents: Long,
          val currency: String, val provider: String, val createdAt: Long, val expiresAt: Long, val status: String,
          val screenshotUrl: String? = null, val reference: String? = null)
class Tx(val id: Long, val txnId: String?, val cents: Long?, val currency: String, val wallet: String?,
         val provider: String, val ts: Long, val raw: String, val status: String, val attempts: Int,
         val nextTry: Long, val reason: String?, val reqId: String?)
class Audit(val ts: Long, val reqId: String?, val txnId: String?, val decision: String, val detail: String, val source: String)
class Out(val id: Long, val key: String, val body: String)

object Db {
    private lateinit var h: SQLiteOpenHelper
    val w: SQLiteDatabase get() = h.writableDatabase
    private const val RC = "request_id,user_id,customer_name,wallet,amount_cents,currency,provider,created_at,expires_at,status,screenshot_url,ref"
    private const val TC = "id,txn_id,amount_cents,currency,wallet,provider,ts,raw,status,attempts,next_try,reason,req_id"

    fun init(c: Context) {
        h = object : SQLiteOpenHelper(c, "agent.db", null, 2) {
            override fun onCreate(d: SQLiteDatabase) {
                d.execSQL("CREATE TABLE requests(request_id TEXT PRIMARY KEY,user_id TEXT,customer_name TEXT,wallet TEXT,amount_cents INTEGER,currency TEXT,provider TEXT,created_at INTEGER,expires_at INTEGER,status TEXT,screenshot_url TEXT,ref TEXT,proof_state TEXT,proof_attempts INTEGER DEFAULT 0)")
                d.execSQL("CREATE TABLE txs(id INTEGER PRIMARY KEY AUTOINCREMENT,txn_id TEXT,amount_cents INTEGER,currency TEXT,wallet TEXT,provider TEXT,ts INTEGER,raw TEXT,status TEXT,attempts INTEGER DEFAULT 0,next_try INTEGER DEFAULT 0,reason TEXT,req_id TEXT)")
                // Unique constraint: a transaction ID can be confirmed only once, ever.
                d.execSQL("CREATE TABLE used_txn(txn_id TEXT PRIMARY KEY)")
                d.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT,ts INTEGER,req_id TEXT,txn_id TEXT,decision TEXT,detail TEXT,source TEXT)")
                d.execSQL("CREATE TABLE outbox(id INTEGER PRIMARY KEY AUTOINCREMENT,k TEXT UNIQUE,body TEXT)")
            }
            override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {
                if (o < 2) {
                    d.execSQL("ALTER TABLE requests ADD COLUMN screenshot_url TEXT")
                    d.execSQL("ALTER TABLE requests ADD COLUMN ref TEXT")
                    d.execSQL("ALTER TABLE requests ADD COLUMN proof_state TEXT")
                    d.execSQL("ALTER TABLE requests ADD COLUMN proof_attempts INTEGER DEFAULT 0")
                }
            }
        }
    }

    private fun <T> Cursor.rows(f: (Cursor) -> T): List<T> {
        val l = ArrayList<T>(); use { while (it.moveToNext()) l.add(f(it)) }; return l
    }
    private fun rowReq(c: Cursor) = Req(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "",
        c.getLong(4), c.getString(5), c.getString(6), c.getLong(7), c.getLong(8), c.getString(9),
        c.getString(10), c.getString(11))
    private fun rowTx(c: Cursor) = Tx(c.getLong(0), c.getString(1), if (c.isNull(2)) null else c.getLong(2), c.getString(3),
        c.getString(4), c.getString(5), c.getLong(6), c.getString(7), c.getString(8), c.getInt(9), c.getLong(10),
        c.getString(11), c.getString(12))

    fun <T> inTx(f: () -> T): T {
        w.beginTransaction()
        try { val r = f(); w.setTransactionSuccessful(); return r } finally { w.endTransaction() }
    }

    // requests
    fun insertRequestIfNew(r: Req) {
        w.insertWithOnConflict("requests", null, ContentValues().apply {
            put("request_id", r.id); put("user_id", r.userId); put("customer_name", r.name); put("wallet", r.wallet)
            put("amount_cents", r.cents); put("currency", r.currency); put("provider", r.provider)
            put("created_at", r.createdAt); put("expires_at", r.expiresAt); put("status", r.status)
            put("screenshot_url", r.screenshotUrl); put("ref", r.reference)
        }, SQLiteDatabase.CONFLICT_IGNORE)
    }
    fun requests(status: String): List<Req> =
        w.rawQuery("SELECT $RC FROM requests WHERE status=? ORDER BY created_at DESC", arrayOf(status)).rows(::rowReq)
    fun pendingByWallet(wallet: String): List<Req> =
        w.rawQuery("SELECT $RC FROM requests WHERE status='PENDING' AND wallet=?", arrayOf(wallet)).rows(::rowReq)
    fun completedMatch(wallet: String, cents: Long): Req? =
        w.rawQuery("SELECT $RC FROM requests WHERE status='CONFIRMED' AND wallet=? AND amount_cents=? LIMIT 1",
            arrayOf(wallet, cents.toString())).rows(::rowReq).firstOrNull()
    fun setRequestStatus(id: String, s: String) {
        w.update("requests", ContentValues().apply { put("status", s) }, "request_id=?", arrayOf(id))
    }

    fun requestById(id: String): Req? =
        w.rawQuery("SELECT $RC FROM requests WHERE request_id=?", arrayOf(id)).rows(::rowReq).firstOrNull()
    fun proofCandidates(): List<Req> =
        w.rawQuery("SELECT $RC FROM requests WHERE status='PENDING' AND proof_state IS NULL AND ((screenshot_url IS NOT NULL AND screenshot_url<>'') OR (ref IS NOT NULL AND ref<>''))", null).rows(::rowReq)
    fun proofAttempts(id: String): Int =
        w.rawQuery("SELECT proof_attempts FROM requests WHERE request_id=?", arrayOf(id)).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun setProof(id: String, state: String?, attempts: Int) {
        w.update("requests", ContentValues().apply { put("proof_state", state); put("proof_attempts", attempts) }, "request_id=?", arrayOf(id))
    }

    // transactions
    fun insertTx(p: Parsed): Long = w.insert("txs", null, ContentValues().apply {
        put("txn_id", p.txnId); put("amount_cents", p.cents); put("currency", p.currency); put("wallet", p.wallet)
        put("provider", p.provider); put("ts", p.ts); put("raw", p.raw); put("status", "PENDING")
    })
    fun tx(id: Long): Tx? = w.rawQuery("SELECT $TC FROM txs WHERE id=?", arrayOf(id.toString())).rows(::rowTx).firstOrNull()
    fun txs(status: String? = null): List<Tx> =
        if (status == null) w.rawQuery("SELECT $TC FROM txs ORDER BY id DESC LIMIT 200", null).rows(::rowTx)
        else w.rawQuery("SELECT $TC FROM txs WHERE status=? ORDER BY id DESC", arrayOf(status)).rows(::rowTx)
    fun due(now: Long): List<Tx> =
        w.rawQuery("SELECT $TC FROM txs WHERE status='PENDING' OR (status='WAITING' AND next_try<=?)", arrayOf(now.toString())).rows(::rowTx)
    fun updateTx(id: Long, status: String, reason: String?, reqId: String?, attempts: Int, nextTry: Long) {
        w.update("txs", ContentValues().apply {
            put("status", status); put("reason", reason); put("req_id", reqId); put("attempts", attempts); put("next_try", nextTry)
        }, "id=?", arrayOf(id.toString()))
    }
    fun counts(): Map<String, Int> {
        val m = HashMap<String, Int>()
        w.rawQuery("SELECT status,COUNT(*) FROM txs GROUP BY status", null).use { while (it.moveToNext()) m[it.getString(0)] = it.getInt(1) }
        return m
    }

    // duplicate protection
    fun isUsed(t: String): Boolean = w.rawQuery("SELECT 1 FROM used_txn WHERE txn_id=?", arrayOf(t)).use { it.moveToFirst() }
    fun markUsed(t: String): Boolean =
        w.insertWithOnConflict("used_txn", null, ContentValues().apply { put("txn_id", t) }, SQLiteDatabase.CONFLICT_IGNORE) != -1L

    // audit log
    fun audit(reqId: String?, txnId: String?, decision: String, detail: String, source: String) {
        w.insert("audit", null, ContentValues().apply {
            put("ts", System.currentTimeMillis()); put("req_id", reqId); put("txn_id", txnId)
            put("decision", decision); put("detail", detail); put("source", source)
        })
    }
    fun auditList(): List<Audit> = w.rawQuery("SELECT ts,req_id,txn_id,decision,detail,source FROM audit ORDER BY id DESC LIMIT 150", null)
        .rows { Audit(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getString(4), it.getString(5)) }

    // outbox (decisions waiting to be reported to the management system)
    fun outboxAdd(key: String, body: String) {
        w.insertWithOnConflict("outbox", null, ContentValues().apply { put("k", key); put("body", body) }, SQLiteDatabase.CONFLICT_IGNORE)
    }
    fun outboxNext(): Out? = w.rawQuery("SELECT id,k,body FROM outbox ORDER BY id LIMIT 1", null)
        .rows { Out(it.getLong(0), it.getString(1), it.getString(2)) }.firstOrNull()
    fun outboxDelete(id: Long) { w.delete("outbox", "id=?", arrayOf(id.toString())) }
    fun outboxClear() { w.delete("outbox", null, null) }
}
