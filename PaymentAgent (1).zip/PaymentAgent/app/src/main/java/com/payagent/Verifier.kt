package com.payagent

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** Client for the Payment Verification API (Telebirr + CBE Birr receipts, screenshot reading). */
object Verifier {
    /** Temporary problem (network, receipt not indexed yet, credits) - try again later. */
    class Retry(msg: String) : Exception(msg)
    /** Definitive problem (unreadable screenshot, unsupported provider) - needs the agent. */
    class Unreadable(msg: String) : Exception(msg)

    class VResult(val success: Boolean, val status: String, val ref: String, val cents: Long?, val payer: String?,
                  val receiver: String?, val date: Long?, val dateText: String?, val detail: String)

    private fun nz(s: String?) = s?.trim()?.takeIf { it.isNotEmpty() && it != "null" }

    private fun http(path: String, ctype: String, body: ByteArray): Pair<Int, String> {
        val base = Store.verifierUrl
        if (!base.startsWith("https://")) throw Retry("Verifier URL must start with https://")
        if (Store.verifierKey.isEmpty()) throw Retry("Verifier API key is not set in Settings")
        try {
            val c = URL(base + path).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 40_000
            c.setRequestProperty("x-api-key", Store.verifierKey)
            c.setRequestProperty("Content-Type", ctype)
            c.doOutput = true; c.outputStream.use { it.write(body) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            return code to text
        } catch (e: Exception) { throw Retry("Verifier unreachable: ${e.message}") }
    }

    fun normProvider(p: String): String? = when (p.lowercase().filter { it.isLetterOrDigit() }) {
        "telebirr" -> "TELEBIRR"; "cbebirr" -> "CBEBIRR"; else -> null
    }

    /** Reads a payment screenshot and returns the receipt reference (Telebirr and CBE Birr receipts). */
    fun readScreenshot(img: ByteArray): String {
        val b = "----pa${System.nanoTime()}"
        val out = ByteArrayOutputStream()
        out.write("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"proof.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray())
        out.write(img); out.write("\r\n--$b--\r\n".toByteArray())
        val (code, text) = http("/verify-image", "multipart/form-data; boundary=$b", out.toByteArray())
        if (code == 422) throw Unreadable("Screenshot not recognized as a Telebirr / CBE Birr receipt")
        if (code != 200) throw Retry("Screenshot reading failed (HTTP $code)")
        val o = JSONObject(text)
        if (o.optString("type") == "cbe") throw Unreadable("CBE bank receipt - only Telebirr and CBE Birr are supported")
        val ref = nz(o.optString("reference")) ?: throw Unreadable("No reference number found in screenshot")
        return ref.uppercase()
    }

    fun check(provider: String, ref: String): VResult {
        val p = normProvider(provider) ?: throw Unreadable("Provider \"$provider\" is not supported (Telebirr / CBE Birr only)")
        return if (p == "TELEBIRR") checkTelebirr(ref) else checkCbeBirr(ref)
    }

    private fun good(st: String) = st.contains("success", true) || st.contains("complete", true)

    private fun checkTelebirr(ref: String): VResult {
        val (code, text) = http("/verify-telebirr", "application/json", JSONObject().put("reference", ref).toString().toByteArray())
        if (code != 200) throw Retry("Telebirr receipt not available (HTTP $code)")
        val o = JSONObject(text)
        if (!o.optBoolean("success", false)) throw Retry(nz(o.optString("error")) ?: "Receipt not found")
        val d = o.getJSONObject("data")
        val st = d.optString("transactionStatus")
        val dt = nz(d.optString("paymentDate"))
        return VResult(good(st), st, nz(d.optString("receiptNo")) ?: ref, Norm.cents(nz(d.optString("settledAmount"))),
            nz(d.optString("payerTelebirrNo")), nz(d.optString("creditedPartyAccountNo")), parseDate(dt), dt, d.toString())
    }

    private fun checkCbeBirr(ref: String): VResult {
        val mine = Norm.wallet(Store.merchantWallet) ?: throw Unreadable("Set your receiving wallet number in Settings")
        val body = JSONObject().put("receiptNumber", ref).put("phoneNumber", "251" + mine.substring(1)).toString()
        val (code, text) = http("/verify-cbebirr", "application/json", body.toByteArray())
        if (code != 200) throw Retry("CBE Birr receipt not available (HTTP $code)")
        val o = JSONObject(text)
        if (o.has("success") && !o.optBoolean("success", true)) throw Retry(nz(o.optString("error")) ?: "Receipt not found")
        val st = o.optString("transactionStatus")
        val dt = nz(o.optString("transactionDate"))
        val amt = nz(o.optString("amount")) ?: nz(o.optString("paidAmount"))
        return VResult(good(st), st, nz(o.optString("receiptNumber")) ?: ref, Norm.cents(amt),
            nz(o.optString("debitAccount")), nz(o.optString("creditAccount")), parseDate(dt), dt, o.toString())
    }

    private val FMTS = listOf("dd-MM-yyyy HH:mm:ss", "dd/MM/yyyy HH:mm:ss", "yyyy-MM-dd HH:mm:ss", "dd-MM-yyyy HH:mm",
        "dd/MM/yyyy HH:mm", "yyyy-MM-dd HH:mm", "yyyy/MM/dd HH:mm:ss", "dd-MMM-yyyy HH:mm:ss", "dd MMM yyyy HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss")
    fun parseDate(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        for (f in FMTS) {
            try {
                val sdf = SimpleDateFormat(f, Locale.US)
                sdf.timeZone = TimeZone.getTimeZone("Africa/Addis_Ababa"); sdf.isLenient = false
                val d = sdf.parse(s.trim()); if (d != null) return d.time
            } catch (_: Exception) {}
        }
        return null
    }
}

/** Automatic proof check: screenshot or reference from the management system request -> verifier -> engine. */
object Proof {
    private fun download(url: String): ByteArray {
        if (!url.startsWith("https://")) throw Verifier.Unreadable("Screenshot link must be HTTPS")
        val u = URL(url)
        val c = u.openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 20_000
        if (u.host == URL(Store.baseUrl).host) Store.token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        val code = c.responseCode
        if (code == 401) throw Api.Unauthorized()
        if (code !in 200..299) throw Verifier.Retry("Screenshot download failed (HTTP $code)")
        val out = ByteArrayOutputStream(); val buf = ByteArray(8192)
        c.inputStream.use { ins ->
            while (true) {
                val n = ins.read(buf); if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > 8 * 1024 * 1024) throw Verifier.Unreadable("Screenshot is too large")
            }
        }
        return out.toByteArray()
    }

    fun runPending() {
        if (Store.demo || Store.verifierKey.isEmpty() || !Store.active()) return
        for (req in Db.proofCandidates()) {
            try {
                val ref = req.reference ?: Verifier.readScreenshot(download(req.screenshotUrl!!))
                Engine.processProof(req, Verifier.check(req.provider, ref.trim().uppercase()), "AUTOMATIC_ENGINE")
                Db.setProof(req.id, "DONE", Db.proofAttempts(req.id))
            } catch (e: Api.Unauthorized) {
                Session.logout("Management session expired - please log in again"); return
            } catch (e: Verifier.Unreadable) {
                Engine.proofFailed(req, e.message ?: "Proof could not be read", "AUTOMATIC_ENGINE")
                Db.setProof(req.id, "DONE", Db.proofAttempts(req.id))
            } catch (e: Exception) {
                val n = Db.proofAttempts(req.id) + 1
                if (n >= Store.maxAttempts) {
                    Engine.proofFailed(req, (e.message ?: "Verifier error") + " (retry limit reached)", "RETRY_LIMIT")
                    Db.setProof(req.id, "DONE", n)
                } else Db.setProof(req.id, null, n)
            }
        }
    }
}
