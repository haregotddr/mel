package com.payagent

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableIntStateOf
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

class App : Application() {
    companion object { lateinit var ctx: Context }
    override fun onCreate() {
        super.onCreate()
        ctx = this
        Store.init(this); Db.init(this); Notifier.channels(this)
    }
}

/** Triggers UI refresh from any thread. */
object Ui {
    val v = mutableIntStateOf(0)
    private val h = Handler(Looper.getMainLooper())
    fun bump() { h.post { v.intValue++ } }
}

/** Encrypted settings + session token (AES256 via Android Keystore). */
object Store {
    private lateinit var p: SharedPreferences
    fun init(c: Context) {
        val mk = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        p = EncryptedSharedPreferences.create(c, "secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }
    var baseUrl: String
        get() = p.getString("url", "https://management.io")!!
        set(v) { p.edit().putString("url", v.trim().trimEnd('/')).apply() }
    var token: String?
        get() = p.getString("token", null)
        set(v) { p.edit().apply { if (v == null) remove("token") else putString("token", v) }.apply() }
    var tokenExp: Long
        get() = p.getLong("exp", 0)
        set(v) { p.edit().putLong("exp", v).apply() }
    var demo: Boolean
        get() = p.getBoolean("demo", false)
        set(v) { p.edit().putBoolean("demo", v).apply() }
    var retrySec: Int
        get() = p.getInt("retry", 10)
        set(v) { p.edit().putInt("retry", v).apply() }
    var maxAttempts: Int
        get() = p.getInt("max", 3)
        set(v) { p.edit().putInt("max", v).apply() }
    var senders: String
        get() = p.getString("senders", "127,telebirr")!!
        set(v) { p.edit().putString("senders", v).apply() }
    var lastSync: Long
        get() = p.getLong("sync", 0)
        set(v) { p.edit().putLong("sync", v).apply() }
    var verifierUrl: String
        get() = p.getString("vurl", "https://verifyapi.leulzenebe.pro")!!
        set(v) { p.edit().putString("vurl", v.trim().trimEnd('/')).apply() }
    var verifierKey: String
        get() = p.getString("vkey", "")!!
        set(v) { p.edit().putString("vkey", v).apply() }
    var merchantWallet: String
        get() = p.getString("mw", "")!!
        set(v) { p.edit().putString("mw", v).apply() }
    /** Local master switch. */
    var automationOn: Boolean
        get() = p.getBoolean("auto", true)
        set(v) { p.edit().putBoolean("auto", v).apply() }
    /** Remote switch controlled by the management system (default: allowed). */
    var serverEnabled: Boolean
        get() = p.getBoolean("srv", true)
        set(v) { p.edit().putBoolean("srv", v).apply() }
    /** Automation runs only when BOTH the agent and the management system allow it. */
    fun active() = automationOn && serverEnabled
    fun loggedIn() = token != null && System.currentTimeMillis() < tokenExp
    fun senderAllowed(s: String) =
        senders.split(",").map { it.trim() }.filter { it.isNotEmpty() }.any { s.equals(it, true) }
}

object Session {
    fun logout(msg: String? = null) {
        Store.token = null; Store.demo = false
        if (msg != null) Notifier.post("Signed out", msg)
        Ui.bump()
    }
}

object Notifier {
    fun channels(c: Context) {
        val m = c.getSystemService(NotificationManager::class.java)
        m.createNotificationChannel(NotificationChannel("events", "Payment events", NotificationManager.IMPORTANCE_HIGH))
        m.createNotificationChannel(NotificationChannel("fg", "Background service", NotificationManager.IMPORTANCE_LOW))
    }
    fun post(title: String, text: String) {
        try {
            val c = App.ctx
            val n = Notification.Builder(c, "events").setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle(title).setContentText(text).setAutoCancel(true).build()
            c.getSystemService(NotificationManager::class.java).notify((System.nanoTime() % 100000).toInt() + 10, n)
        } catch (_: Exception) {}
    }
    fun foreground(c: Context): Notification =
        Notification.Builder(c, "fg").setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Payment automation running").setContentText("Monitoring payments").setOngoing(true).build()
}

// ---------- Normalization & parsing ----------
object Norm {
    fun wallet(s: String?): String? {
        if (s == null) return null
        var d = s.filter { it.isDigit() }
        if (d.startsWith("251")) d = "0" + d.substring(3)
        if (d.length == 9) d = "0$d"
        return if (d.length == 10) d else null
    }
    fun cents(s: String?): Long? {
        val c = s?.replace(",", "")?.filter { it.isDigit() || it == '.' }
        if (c.isNullOrEmpty()) return null
        return try { BigDecimal(c).movePointRight(2).setScale(0, RoundingMode.HALF_UP).toLong() } catch (_: Exception) { null }
    }
}

object Fmt {
    fun money(c: Long?, cur: String) = if (c == null) "?" else String.format(Locale.US, "%d.%02d %s", c / 100, c % 100, cur)
}

class Parsed(val txnId: String?, val cents: Long?, val currency: String, val wallet: String?,
             val provider: String, val ts: Long, val raw: String)

object Parser {
    private val TXN = Regex("""(?i)(?:transaction\s*(?:number|id|no\.?)|txn\s*(?:id|no)?|ref(?:erence)?)\s*(?:is|:|#)?\s*((?=[A-Z0-9]*\d)[A-Z0-9]{8,})""")
    private val AMT = Regex("""(?i)(?:ETB|birr)\s*([\d,]+(?:\.\d{1,2})?)|([\d,]+(?:\.\d{1,2})?)\s*(?:ETB|birr)""")
    private val WAL = Regex("""(?:\+?251|0)9\d{8}""")
    fun parse(raw: String, ts: Long = System.currentTimeMillis()): Parsed {
        val a = AMT.find(raw)
        val amt = a?.groupValues?.get(1)?.takeIf { it.isNotEmpty() } ?: a?.groupValues?.get(2)
        val provider = if (Regex("(?i)cbe|m-?pesa|awash").containsMatchIn(raw)) "Other" else "Telebirr"
        return Parsed(TXN.find(raw)?.groupValues?.get(1)?.uppercase(), Norm.cents(amt),
            if (Regex("(?i)usd").containsMatchIn(raw)) "USD" else "ETB",
            Norm.wallet(WAL.find(raw)?.value), provider, ts, raw)
    }
}

object Intake {
    /** Called for every allow-listed payment SMS (or the in-app test box). */
    fun ingest(body: String) {
        if (!body.contains("received", true)) return
        val id = Db.insertTx(Parser.parse(body))
        Engine.process(id)
        Ui.bump()
    }
}
