package com.payagent

import org.json.JSONObject

/** Matching + decision engine and state machine. */
object Engine {
    private val ALLOWED = mapOf(
        "PENDING" to setOf("CONFIRMED", "REJECTED", "WAITING", "EXCEPTION"),
        "WAITING" to setOf("CONFIRMED", "REJECTED", "EXCEPTION"),
        "EXCEPTION" to setOf("CONFIRMED", "REJECTED"))
    fun canMove(from: String, to: String) = ALLOWED[from]?.contains(to) == true

    class Rule(val name: String, val ok: Boolean)
    class Eval(val decision: String, val rules: List<Rule>, val reason: String, val req: Req?)

    private fun parsed(t: Tx) = Parsed(t.txnId, t.cents, t.currency, t.wallet, t.provider, t.ts, t.raw)

    fun evaluate(p: Parsed): Eval {
        val rules = mutableListOf<Rule>()
        val tid = p.txnId; val cents = p.cents; val wal = p.wallet
        if (tid == null || cents == null || wal == null) return Eval("WAIT", rules, "Notification incomplete", null)
        val dup = Db.isUsed(tid)
        rules += Rule("Transaction uniqueness", !dup)
        if (dup) return Eval("REJECT", rules, "Duplicate transaction ID", null)
        val cands = Db.pendingByWallet(wal)
        if (cands.isEmpty()) {
            val done = Db.completedMatch(wal, cents)
            return if (done != null) Eval("REJECT", rules + Rule("Request is pending", false), "Belongs to an already completed request", done)
            else Eval("WAIT", rules, "No matching request yet", null)
        }
        val exact = cands.filter { it.cents == cents }
        if (exact.size > 1 || (cands.size > 1 && exact.isEmpty())) return Eval("EXCEPTION", rules, "Multiple possible matches", null)
        val req = exact.firstOrNull() ?: cands[0]
        rules += Rule("Request exists", true)
        rules += Rule("Request is pending", req.status == "PENDING")
        rules += Rule("Provider", p.provider.equals(req.provider, true))
        rules += Rule("Currency", p.currency.equals(req.currency, true))
        rules += Rule("Amount", cents == req.cents)
        rules += Rule("Wallet", wal == req.wallet)
        rules += Rule("Time window", p.ts >= req.createdAt - 60_000 && p.ts <= req.expiresAt)
        val failed = rules.filter { !it.ok }.map { it.name }
        return if (failed.isEmpty()) Eval("CONFIRM", rules, "All rules passed", req)
        else Eval("REJECT", rules, "Failed: " + failed.joinToString(", "), req)
    }

    @Synchronized
    fun process(id: Long, source: String = "AUTOMATIC_ENGINE") {
        val tx = Db.tx(id) ?: return
        if (tx.status != "PENDING" && tx.status != "WAITING") return
        if (!Store.active()) { // system switched OFF: record only, never decide
            Db.updateTx(id, tx.status, "Automation is OFF - waiting", tx.reqId, tx.attempts, tx.nextTry)
            return
        }
        // Never decide on stale data: offline / unsynced => no decision, no retry consumed.
        if (!Sync.fresh()) {
            Db.updateTx(id, tx.status, "Waiting for synchronization (no decision while offline)", tx.reqId, tx.attempts, tx.nextTry)
            return
        }
        apply(tx, evaluate(parsed(tx)), source)
    }

    private fun apply(tx: Tx, e: Eval, source: String) {
        when (e.decision) {
            "CONFIRM" -> {
                val ok = Db.inTx { if (!Db.markUsed(tx.txnId!!)) false else { Db.setRequestStatus(e.req!!.id, "CONFIRMED"); true } }
                if (ok) finish(tx, "CONFIRMED", source, e.rules, e.reason, e.req)
                else finish(tx, "REJECTED", source, e.rules, "Duplicate transaction ID (database constraint)", e.req)
            }
            "REJECT" -> finish(tx, "REJECTED", source, e.rules, e.reason, e.req)
            "EXCEPTION" -> finish(tx, "EXCEPTION", source, e.rules, e.reason, e.req)
            else -> {
                val n = tx.attempts + 1
                if (n >= Store.maxAttempts) finish(tx, "EXCEPTION", "RETRY_LIMIT", e.rules, e.reason + " (retry limit reached)", null, n)
                else {
                    Db.updateTx(tx.id, "WAITING", e.reason, null, n, System.currentTimeMillis() + Store.retrySec * 1000L)
                    if (tx.status == "PENDING") Db.audit(null, tx.txnId, "WAITING", e.reason, source)
                    Ui.bump()
                }
            }
        }
    }

    // ---------- Screenshot / reference proof ----------
    private const val LOOKBACK_MS = 2 * 3_600_000L

    fun evaluateProof(req: Req, vr: Verifier.VResult): Eval {
        val rules = mutableListOf<Rule>()
        val mine = Norm.wallet(Store.merchantWallet)
            ?: return Eval("EXCEPTION", rules, "Set your receiving wallet number in Settings", req)
        val dup = Db.isUsed(vr.ref)
        rules += Rule("Reference unused", !dup)
        if (dup) return Eval("REJECT", rules, "Reference already used", req)
        rules += Rule("Receipt status successful", vr.success)
        if (!vr.success) return Eval("REJECT", rules, "Receipt status: ${vr.status}", req)
        val rx = Norm.wallet(vr.receiver); val px = Norm.wallet(vr.payer); val cents = vr.cents; val date = vr.date
        if (cents == null || rx == null || px == null || date == null)
            return Eval("EXCEPTION", rules, "Receipt details unreadable (amount, receiver, payer or date)", req)
        rules += Rule("Request pending", req.status == "PENDING")
        rules += Rule("Amount", cents == req.cents)
        rules += Rule("Receiver is my wallet", rx == mine)
        rules += Rule("Payer wallet", px == req.wallet)
        rules += Rule("Time window", date >= req.createdAt - LOOKBACK_MS && date <= req.expiresAt)
        val failed = rules.filter { !it.ok }.map { it.name }
        return if (failed.isEmpty()) Eval("CONFIRM", rules, "Receipt verified", req)
        else Eval("REJECT", rules, "Failed: " + failed.joinToString(", "), req)
    }

    private fun newProofTx(req: Req, vr: Verifier.VResult): Tx? {
        val id = Db.insertTx(Parsed(vr.ref, vr.cents, "ETB", Norm.wallet(vr.payer), req.provider,
            vr.date ?: System.currentTimeMillis(), "Verified receipt: " + vr.detail))
        Db.updateTx(id, "PENDING", null, req.id, 0, 0)
        return Db.tx(id)
    }

    @Synchronized
    fun processProof(req: Req, vr: Verifier.VResult, source: String) {
        val fresh = Db.requestById(req.id) ?: return
        if (fresh.status != "PENDING") return
        val tx = newProofTx(fresh, vr) ?: return
        apply(tx, evaluateProof(fresh, vr), source)
    }

    @Synchronized
    fun proofFailed(req: Req, msg: String, source: String) {
        val fresh = Db.requestById(req.id) ?: return
        val id = Db.insertTx(Parsed(req.reference, null, "ETB", null, req.provider, System.currentTimeMillis(), "No receipt verification: $msg"))
        Db.updateTx(id, "PENDING", null, req.id, 0, 0)
        val tx = Db.tx(id) ?: return
        apply(tx, Eval("EXCEPTION", emptyList(), msg + " - use the Verify tab", fresh), source)
    }

    /** Agent checked a reference by hand and decides. */
    @Synchronized
    fun manualProof(req: Req, vr: Verifier.VResult, to: String) {
        val fresh = Db.requestById(req.id) ?: return
        if (fresh.status != "PENDING") { Notifier.post("Blocked", "Request is no longer pending"); return }
        val e = evaluateProof(fresh, vr)
        if (to == "CONFIRMED") {
            if (!vr.success) { Notifier.post("Cannot confirm", "Receipt status is ${vr.status}"); return }
            val ok = Db.inTx { if (!Db.markUsed(vr.ref)) false else { Db.setRequestStatus(fresh.id, "CONFIRMED"); true } }
            if (!ok) { Notifier.post("Blocked", "Reference already used"); return }
            val tx = newProofTx(fresh, vr) ?: return
            val note = if (e.decision == "CONFIRM") "Manual reference check" else "Manual override - engine said ${e.decision}: ${e.reason}"
            finish(tx, "CONFIRMED", "AGENT_MANUAL", e.rules, note, fresh)
        } else {
            val tx = newProofTx(fresh, vr) ?: return
            finish(tx, "REJECTED", "AGENT_MANUAL", e.rules, "Manual rejection", fresh)
        }
    }

    fun tick() { Db.due(System.currentTimeMillis()).forEach { process(it.id, "RETRY_ENGINE") } }

    @Synchronized
    fun manual(id: Long, to: String) {
        val tx = Db.tx(id) ?: return
        if (!canMove(tx.status, to)) return
        if (to == "CONFIRMED") {
            val w = tx.wallet; val c = tx.cents; val t = tx.txnId
            if (w == null || c == null || t == null) { Notifier.post("Cannot confirm", "Transaction information is incomplete"); return }
            val req = Db.pendingByWallet(w).firstOrNull { it.cents == c }
            if (req == null) { Notifier.post("Cannot confirm", "No matching pending request"); return }
            val ok = Db.inTx { if (!Db.markUsed(t)) false else { Db.setRequestStatus(req.id, "CONFIRMED"); true } }
            if (!ok) { Notifier.post("Blocked", "Transaction ID already used"); return }
            finish(tx, "CONFIRMED", "AGENT_MANUAL", emptyList(), "Manual agent resolution", req)
        } else finish(tx, "REJECTED", "AGENT_MANUAL", emptyList(), "Manual agent resolution", null)
    }

    private fun finish(tx: Tx, to: String, source: String, rules: List<Rule>, reason: String, req: Req?, attempts: Int = tx.attempts) {
        if (!canMove(tx.status, to)) return
        Db.updateTx(tx.id, to, reason, req?.id, attempts, 0)
        val detail = buildString {
            append(reason)
            append("\nRequested: ").append(if (req != null) Fmt.money(req.cents, req.currency) + " / " + req.wallet else "—")
            append("\nReceived: ").append(Fmt.money(tx.cents, tx.currency)).append(" / ").append(tx.wallet ?: "?")
            if (rules.isNotEmpty()) append("\n").append(rules.joinToString("  ") { (if (it.ok) "✓ " else "✗ ") + it.name })
        }
        Db.audit(req?.id, tx.txnId, to, detail, source)
        if (to == "CONFIRMED" || to == "REJECTED") {
            val body = JSONObject().put("request_id", req?.id ?: JSONObject.NULL).put("transaction_id", tx.txnId ?: JSONObject.NULL)
                .put("decision", to).put("amount", (tx.cents ?: 0) / 100.0).put("wallet", tx.wallet ?: JSONObject.NULL)
                .put("reason", reason).put("source", source).put("decided_at", java.time.Instant.now().toString())
            Db.outboxAdd(tx.txnId ?: "tx${tx.id}", body.toString())
        }
        Notifier.post(when (to) { "CONFIRMED" -> "Payment confirmed"; "REJECTED" -> "Payment rejected"; else -> "Payment needs attention" },
            (tx.txnId ?: "incomplete") + ": " + reason)
        Ui.bump()
    }
}
